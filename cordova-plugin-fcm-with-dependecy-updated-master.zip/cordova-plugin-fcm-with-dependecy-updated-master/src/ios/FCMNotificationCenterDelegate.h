#import <UIKit/UIKit.h>

@interface FCMNotificationCenterDelegate : NSObject {}

- (void)configureForNotifications;

@end
